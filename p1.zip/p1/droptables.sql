drop table Customer;
drop table Supplier;
drop table Product;
drop table Inventory;
drop table Orders;

drop table OrderItems;

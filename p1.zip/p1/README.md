First Name: Ji
Last Name: Ma
Email: ma438@purdue.edu
